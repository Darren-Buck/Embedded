#ifndef MORSE_H
#define MORSE_H

void translate_to_morse(const char *input, char *output, int output_size);
void morse_blink_led(const char *input);

#endif
#ifndef __FONT_H
#define __FONT_H

#include <stdint.h>
#include <inttypes.h>

extern const uint8_t font5x7[];
extern const uint8_t font8x8[];

#endif
